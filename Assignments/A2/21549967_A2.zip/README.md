# COS 314 Assignment 2


## Prerequisites

- JDK 17 or higher


## Usage

1. Double click on the run.bat file to execute it
2. The application should now start running.
3. Once it is complete, you can view the results in the "Results" folder.

## Issues
If the bat file does not run, please consider using VS Code with the Java extension or an IDE. The program does run perfectly,
but I had a few issues when getting it to run manually. If you still encounter issues, please feel free to contact me on Discord
or email me u21549967@tuks.co.za

## Contributors

Keelan Matthews - u21549967